int bitNor(int, int);
int test_bitNor(int, int);

int isZero(int);
int test_isZero(int);

int addOK(int);
int test_addOK(int);

int logicalShift(int, int);
int test_logicalShift(int, int);

int absVal(int);
int test_absVal(int);
