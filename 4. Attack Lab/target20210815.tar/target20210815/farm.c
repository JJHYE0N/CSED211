/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_459()
{
    return 2462550344U;
}

unsigned getval_121()
{
    return 1479595564U;
}

unsigned addval_498(unsigned x)
{
    return x + 499341554U;
}

void setval_386(unsigned *p)
{
    *p = 2455256461U;
}

unsigned getval_448()
{
    return 3284633944U;
}

unsigned addval_454(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_197(unsigned x)
{
    return x + 2428995912U;
}

unsigned getval_211()
{
    return 2425393496U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_134(unsigned *p)
{
    *p = 2915156361U;
}

void setval_480(unsigned *p)
{
    *p = 3527985801U;
}

unsigned getval_342()
{
    return 3286272328U;
}

void setval_281(unsigned *p)
{
    *p = 2445969831U;
}

unsigned getval_356()
{
    return 2425539209U;
}

void setval_237(unsigned *p)
{
    *p = 3526940297U;
}

unsigned getval_149()
{
    return 3674784009U;
}

unsigned addval_133(unsigned x)
{
    return x + 3286280520U;
}

unsigned getval_417()
{
    return 2430634328U;
}

void setval_478(unsigned *p)
{
    *p = 3375945355U;
}

unsigned getval_101()
{
    return 3286272328U;
}

unsigned getval_184()
{
    return 3284830692U;
}

unsigned addval_370(unsigned x)
{
    return x + 2464188744U;
}

void setval_251(unsigned *p)
{
    *p = 3352725772U;
}

unsigned getval_451()
{
    return 2430642504U;
}

void setval_307(unsigned *p)
{
    *p = 3380920713U;
}

unsigned addval_145(unsigned x)
{
    return x + 3281043865U;
}

unsigned getval_449()
{
    return 3531915721U;
}

unsigned getval_484()
{
    return 3252717896U;
}

unsigned getval_341()
{
    return 3229931145U;
}

unsigned addval_217(unsigned x)
{
    return x + 3380926121U;
}

unsigned addval_255(unsigned x)
{
    return x + 3375415689U;
}

unsigned getval_111()
{
    return 3380920712U;
}

unsigned addval_395(unsigned x)
{
    return x + 3677410953U;
}

void setval_127(unsigned *p)
{
    *p = 3676359321U;
}

void setval_420(unsigned *p)
{
    *p = 3523791497U;
}

unsigned getval_306()
{
    return 3230979721U;
}

unsigned addval_159(unsigned x)
{
    return x + 3224945033U;
}

void setval_421(unsigned *p)
{
    *p = 3353381192U;
}

unsigned addval_279(unsigned x)
{
    return x + 3523267209U;
}

void setval_324(unsigned *p)
{
    *p = 3380923019U;
}

unsigned getval_398()
{
    return 3525367465U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
